enum ConnectivityStatus { Wifi, Cellular, Offline }
