import 'package:geolocator/geolocator.dart';

class PositionResponse {
  Position position;
  bool timedOut = false;
}