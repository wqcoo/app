import 'package:flutter/material.dart';
 
class UIColors {
  static Color primary = Color(0xFF1d55f3);
}
